# Top 5% income share

## About this example

A Streamlit application makes it easy to transform your analysis into an interactive dashboard using Python so users can ask and answer questions in real-time, without having to touch any code.


## Learn more

* [Streamlit Getting Started Guide](https://docs.streamlit.io/en/latest/getting_started.html)
* [RStudio Connect User Guide: Streamlit](https://docs.rstudio.com/connect/user/streamlit/)

## Requirements

* Python 3 versions 3.5 or higher

<!-- NOTE: this file is generated -->
